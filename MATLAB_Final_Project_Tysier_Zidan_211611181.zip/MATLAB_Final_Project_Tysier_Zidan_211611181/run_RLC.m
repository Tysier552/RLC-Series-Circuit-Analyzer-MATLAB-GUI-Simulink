R = evalin('base', 'R');
C=evalin('base','C');
L=evalin('base','L');
f=evalin('base','f');
ScopeData = evalin('base', 'ScopeData');
w=2*pi*f;

t=ScopeData.time;
I_total=ScopeData.signals(1).values(:, 1);
V_S=ScopeData.signals(2).values(:,1);
V_R=ScopeData.signals(3).values(:,1);
Z_L=1j*w*L;
Z_C = 1 / (1j * w * C);
V_C=I_total*Z_C;
V_L=I_total*Z_L;
%plot voltages and current from Simulink Model.
figure;
subplot(3, 1, 1);
plot(t, V_R , 'r'); %Voltage for Resistor
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Voltage across Resistor (V_R)');
grid on;

subplot(3, 1, 2);
plot(t, real(V_L), 'g'); %Voltage for Inductor
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Voltage across Inductor (V_L)');
grid on;
    
subplot(3, 1, 3);
plot(t,real(V_C), 'b'); %Voltage for Capacitor
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Voltage across Capacitor (V_C)');
grid on;

figure;
plot(t, real(I_total), 'k'); % Circuit current (I(t))
xlabel('Time (s)');
ylabel('Current (A)');
title('Current through the Circuit');
grid on;

%Calculate Solution Using Phasors. 

w=2*pi*f;
Vs=1;
Z_total = R + Z_L + Z_C;
I_phasor = Vs / Z_total;
V_R_phasor = I_phasor * R;
V_L_phasor = I_phasor * Z_L;
V_C_phasor = I_phasor * Z_C;

%plotting the magnitude and phase of voltage phasors and current phasor.

% Magnitudes

mag_V_R = abs(V_R_phasor);
mag_V_L = abs(V_L_phasor);
mag_V_C = abs(V_C_phasor);
mag_I = abs(I_phasor);

% Phases

phase_V_R = angle(V_R_phasor);
phase_V_L = angle(V_L_phasor);
phase_V_C = angle(V_C_phasor);
phase_I = angle(I_phasor);

fprintf('Magnitude Comparison:\n');
fprintf('V_R magnitude: Phasor = %.5e, Simulink = %.5e\n', mag_V_R, max(abs(V_R)));
fprintf('V_L magnitude: Phasor = %.5e, Simulink = %.5e\n', mag_V_L, max(abs(V_L)));
fprintf('V_C magnitude: Phasor = %.5e, Simulink = %.5e\n', mag_V_C, max(abs(V_C)));

figure;
subplot(2,4,1); %current magnitude
plot([0 1], [mag_I mag_I], 'r', 'LineWidth', 1,'Marker','o');
title('|I(t) Phasor|');
xlabel('Time (s)');
ylabel('|I(t) Phasor|');
yticks(mag_I);
yticklabels({num2str(mag_I)});
ylim([0 mag_I*1.1]);
grid on;

subplot(2,4,2); %resistor voltage magnitude
plot([0 1], [mag_V_R mag_V_R], 'r', 'LineWidth', 1,'Marker','o');
title('|V(R) Phasor|');
xlabel('Time (s)');
ylabel('|V(R) Phasor|');
yticks(mag_V_R);
yticklabels({num2str(mag_V_R)});
ylim([0 mag_V_R*1.1]);
grid on;

subplot(2,4,3); %inductor voltage magnitude
plot([0 1], [mag_V_L mag_V_L], 'r', 'LineWidth', 1,'Marker','o');
title('|V(L) Phasor|');
xlabel('Time (s)');
ylabel('|V(L) Phasor|');
yticks(mag_V_L);
yticklabels({num2str(mag_V_L)});
ylim([0 mag_V_L*1.1]);
grid on;

subplot(2,4,4); %capacitor voltage magnitude
plot([0 1], [mag_V_C mag_V_C], 'r', 'LineWidth', 1,'Marker','o');
title('|V(C) Phasor|');
xlabel('Time (s)');
ylabel('|V(C) Phasor|');
yticks(mag_V_C);
yticklabels({num2str(mag_V_C)});
ylim([0 mag_V_C*1.1]);
grid on;

subplot(2,4,5); %current phase
plot([0 1], rad2deg([phase_I phase_I]), 'r', 'LineWidth', 1,'Marker','o');
title('\angle I phasor');
xlabel('Time (s)');
ylabel('\angle I phasor');
yticks(rad2deg(phase_I));
yticklabels({num2str(rad2deg(phase_I))});
ylim([rad2deg(phase_I-10) rad2deg(phase_I+10)]);
grid on;

subplot(2,4,6); % resistor voltage phase
plot([0 1], rad2deg([phase_V_R phase_V_R]), 'r', 'LineWidth', 1,'Marker','o');
title('\angle VR phasor');
xlabel('Time (s)');
ylabel('\angle VR phasor');
yticks(rad2deg(phase_V_R));
yticklabels({num2str(rad2deg(phase_V_R))});
ylim([rad2deg(phase_V_R-10)  rad2deg(phase_V_R+10)]);
grid on;

subplot(2,4,7) % inductor voltage phase 
plot([0 1], rad2deg([phase_V_L phase_V_L]), 'r', 'LineWidth', 1,'Marker','o');
title('\angle VL phasor');
xlabel('Time (s)');
ylabel('\angle VL phasor');
yticks(rad2deg(phase_V_L));
yticklabels({num2str(rad2deg(phase_V_L))});
ylim([rad2deg(phase_V_L-10) rad2deg(phase_V_L+10)]);
grid on;

subplot(2,4,8); %capacitor voltage phase 
plot([0 1], rad2deg([phase_V_C phase_V_C]), 'r', 'LineWidth', 1,'Marker','o');
title('\angle VC phasor');
xlabel('Time (s)');
ylabel('\angle VC phasor');
yticks(rad2deg(phase_V_C));
yticklabels({num2str(rad2deg(phase_V_C))});
ylim([rad2deg(phase_V_C-10) rad2deg(phase_V_C+10)]);
grid on;

% converting phasors to time domain for comparison.

I_t = abs(I_phasor) * sin(w * t + angle(I_phasor));
V_R_t = abs(V_R_phasor) * sin(w * t + angle(V_R_phasor));
V_L_t = abs(V_L_phasor) * cos(w * t + angle(V_L_phasor));
V_C_t = abs(V_C_phasor) * cos(w * t + angle(V_C_phasor));

%plotting phasors after we brought them back to the time domain. 
figure;
subplot(3, 1, 1);
plot(t, V_R_t, 'r');
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Phasor Voltage across Resistor (V_R)');
grid on;
    
subplot(3, 1, 2);
plot(t, V_L_t, 'g');
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Phasor Voltage across Inductor (V_L)');
grid on;
    
subplot(3, 1, 3);
plot(t, V_C_t, 'b');
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Phasor Voltage across Capacitor (V_C)');
grid on;
    
% Plot phasor solution current
figure;
plot(t, I_t, 'k');
xlabel('Time (s)');
ylabel('Current (A)');
title('Phasor Current through the Circuit');
grid on;